<?php
$servername = "localhost"; 
$username = "root";        
$password = "";           
$database = "mydb";    

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// header('Content-Type: application/json');

if (isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action == 'check_email') {
        $email = $_POST['email'];
        $query = "SELECT * FROM users WHERE `email` = '$email'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            echo 'exists';
        } else {
            echo 'does not exist';
        }
    } elseif ($action == 'check_username') {
        $username = $_POST['username'];
        $query = "SELECT * FROM users WHERE `username` = '$username'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            echo 'exists';
        } else {
            echo 'does not exist';
        }
    } else {
        
    }
}
?>
