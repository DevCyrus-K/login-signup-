document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("loan-application-form");

    form.addEventListener("submit", function(event) {
        event.preventDefault();

        const formData = new FormData(form);

        const data = {
            name: formData.get("name"),
            email: formData.get("email"),
            phone: formData.get("phone"),
            member_id: formData.get("member-id"),
            loan_amount: formData.get("loan-amount"),
            loan_purpose: formData.get("loan-purpose"),
            repayment_period: formData.get("repayment-period")
        };

        
        fetch('submit-loan-application.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(result => {
            alert("Application submitted successfully.");
            // Optionally redirect to admin.php if needed
            window.location.href = 'admin.php';
        })
        .catch(error => {
            console.error('Error:', error);
            alert("An error occurred while submitting the application.");
        });
    });
});
