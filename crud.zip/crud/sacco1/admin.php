<?php
// $filename = 'applications.json';
// $applications = [];

// if (file_exists($filename)) {
//     $applications = json_decode(file_get_contents($filename), true);
// }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Loan Applications</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <h2>Admin - View Loan Applications</h2>
        <div id="applications-container">
            <h3>Submitted Loan Applications:</h3>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <?php 
                        require 'backend/connection.php';
                        $query = mysqli_query($conn, "SELECT * FROM loan_applications");
                        if($query){
                        ?>
                        <thead class="text-start text-secondary text-uppercase">
                        <th>#</th>
                        <th>Fullname</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>ID</th>
                        <th>Amount</th>
                        <th>Repayment</th>
                        <th></th>
                    </thead>
                    <tbody>
                    <?php
                    $count = 1;
                    while($row = $query->fetch_assoc()){
                        echo "<tr>
                            <td>".$count."</td>";
                            echo "<td>".$row['fullname']."</td>";
                            echo "<td>".$row['email']."</td>";
                            echo "<td>".$row['phone']."</td>";
                            echo "<td>".$row['member_id']."</td>";
                            echo "<td>".$row['loan_amount']."</td>";
                            echo "<td>".$row['repayment_period']."</td>";
                            echo "<td><button class='btn btn-sm btn-success'>Edit</button>
                                        <button class='btn btn-sm btn-danger'>Del</button>
                            </td>";
                        echo "</tr>";
                        $count ++;
                    }
                    ?>
                
                    </tbody>
                        <?php
                        }else{
                            echo "<p>No records found</p>";
                        }
                    ?>
                    
                </table>
            </div>
            <?php if (!empty($applications)): ?>
                <ul id="applications-list">
                    <?php foreach ($applications as $index => $application): ?>
                        <li>
                            <strong>Application <?php echo $index + 1; ?>:</strong><br>
                            Name: <?php echo htmlspecialchars($application['name']); ?><br>
                            Email: <?php echo htmlspecialchars($application['email']); ?><br>
                            Phone: <?php echo htmlspecialchars($application['phone']); ?><br>
                            Member ID: <?php echo htmlspecialchars($application['member_id']); ?><br>
                            Loan Amount: <?php echo htmlspecialchars($application['loan_amount']); ?><br>
                            Purpose: <?php echo htmlspecialchars($application['loan_purpose']); ?><br>
                            Repayment Period: <?php echo htmlspecialchars($application['repayment_period']); ?> months
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
            <?php endif; ?>
            <button onclick="printApplications()">Print Applications</button>
            <a href="applications.json" download class="button">Download Applications</a>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        function printApplications() {
            window.print();
        }
    </script>
</body>
</html>
