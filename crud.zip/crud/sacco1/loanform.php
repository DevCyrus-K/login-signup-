<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smartlife SACCO Loan Application Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container-fluid bg-light">
        <div class="row">
            <div class="col-12 col-md-8 col-lg-8 bg-white p-2">
                <h2>Smartlife SACCO Loan Application Form</h2>
                <form id='loan_form' method="POST">
                    <div class="form-group">
                        <label for="name">Full Name:</label>
                        <input type="text" id="name" name="name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email Address:</label>
                        <input type="email" id="email" name="email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone Number:</label>
                        <input type="tel" id="phone" name="phone" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="member-id">Member ID:</label>
                        <input type="text" id="member-id" name="member-id" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="loan-amount">Loan Amount:</label>
                        <input type="number" id="loan-amount" name="loan-amount" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="loan-purpose">Purpose of Loan:</label>
                        <textarea id="loan-purpose" name="loan-purpose" class="form-control" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="repayment-period">Repayment Period (months):</label>
                        <input type="number" id="repayment-period" name="repayment-period" class="form-control" required>
                    </div>
                    <div class="form-group mt-3">
                        <button class="btn btn-success" type="submit">Submit Application</button>
                    </div>
                </form>
            </div>
            <div class="col-md-4"></div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.min.js" integrity="sha512-ykZ1QQr0Jy/4ZkvKuqWn4iF3lqPZyij9iRv6sGqLRdTPkY69YX6+7wvVGmsdBbiIfN/8OdsI7HABjvEok6ZopQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="includes/js/main.js"></script>
</body>
</html>
