<?php
$filename = 'applications.json';
$applications = [];

if (file_exists($filename)) {
    $applications = json_decode(file_get_contents($filename), true);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Loan Applications</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <h2>Admin - View Loan Applications</h2>
        <div id="applications-container">
            <h3>Submitted Loan Applications:</h3>
            <ul id="applications-list">
                <?php foreach ($applications as $index => $application): ?>
                    <li>
                        <strong>Application <?php echo $index + 1; ?>:</strong><br>
                        Name: <?php echo $application['name']; ?><br>
                        Email: <?php echo $application['email']; ?><br>
                        Phone: <?php echo $application['phone']; ?><br>
                        Member ID: <?php echo $application['memberId']; ?><br>
                        Loan Amount: <?php echo $application['loanAmount']; ?><br>
                        Purpose: <?php echo $application['loanPurpose']; ?><br>
                        Repayment Period: <?php echo $application['repaymentPeriod']; ?> months
                    </li>
                <?php endforeach; ?>
            </ul>
            <button onclick="printApplications()">Print Applications</button>
            <a href="download.php" class="button">Download Applications</a>
        </div>
    </div>
    <script>
        function printApplications() {
            window.print();
        }
    </script>
</body>
</html>
