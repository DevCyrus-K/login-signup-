<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'name' => $_POST['name'],
        'email' => $_POST['email'],
        'phone' => $_POST['phone'],
        'member_id' => $_POST['member-id'],
        'loan_amount' => $_POST['loan-amount'],
        'loan_purpose' => $_POST['loan-purpose'],
        'repayment_period' => $_POST['repayment-period']
    ];

    $filename = 'applications.json';
    if (file_exists($filename)) {
        $applications = json_decode(file_get_contents($filename), true);
    } else {
        $applications = [];
    }

    $applications[] = $data;
    file_put_contents($filename, json_encode($applications, JSON_PRETTY_PRINT));

    // Redirect to the admin page
    header('Location: admin.php');
    exit;
} else {
    echo "Invalid request method.";
}
?>
