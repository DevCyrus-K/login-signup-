<?php
$servername = "localhost"; 
$username = "root";        
$password = "";           
$database = "sacco_db";    

$conn = new mysqli($servername, $username, $password, $database);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$fullname = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$member_id = $_POST['member-id'];
$loan_amount = $_POST['loan-amount'];
$loan_purpose = $_POST['loan-purpose'];
$repayment_period = $_POST['repayment-period'];


$res = mysqli_query($conn, "INSERT INTO loan_applications (fullname, email, phone, member_id, loan_amount, loan_purpose, repayment_period)
                    VALUES('$fullname', '$email', '$phone', '$member_id', '$loan_amount', '$loan_purpose', '$repayment_period')");
if($res === true){
    echo "success";
}else{
    // echo mysqli_error($conn);
    echo "An error occurred. Contact ICT";
}