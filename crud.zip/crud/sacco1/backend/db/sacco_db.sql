
-- Create the database
CREATE DATABASE sacco_db;

-- Use the database
USE sacco_db;

-- Create the loan_applications table
CREATE TABLE loan_applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    member_id VARCHAR(50) NOT NULL,
    loan_amount DECIMAL(10, 2) NOT NULL,
    loan_purpose TEXT NOT NULL,
    repayment_period INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
