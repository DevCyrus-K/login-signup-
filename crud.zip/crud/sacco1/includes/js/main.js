$(document).ready(function () {
    $("#loan_form").submit(function (e) { 
        e.preventDefault(); 
        
        let formData = $(this).serialize(); 
        // console.log(formData);
        $.ajax({
            type: "POST",  
            url: "backend/action.php",  
            data: formData,  
            // dataType: "json", 
            success: function (response) {
                console.log(response);
                if(response == "success"){
                    alert("Operation successful");
                }else{
                    alert("Operation failed");
                }
            },
            
        });
    });
});
