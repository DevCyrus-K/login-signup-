<?php
session_start();


if (isset($_SESSION['username'])) {
    
    header('Location: sacco/loanform.php');
    exit;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['signup'])) {
       
        $_SESSION['username'] = $_POST['username'];
        header('Location: sacco/loanform.php');
        exit;
    } elseif (isset($_POST['login'])) {
       
        $_SESSION['username'] = $_POST['email']; 
        header('Location: crud\sacco1/loanform.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Sign up / Login Form</title>
    <link rel="stylesheet" href="includes/css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastr@2.1.4/build/toastr.min.css">
</head>

<body>
    <div class="main">
        <input type="checkbox" id="chk" aria-hidden="true">

        <div class="signup">
            <form id='signup'>
                <label for="chk" aria-hidden="true">Sign up</label>
                <input type="text" name="username" placeholder="Username" id="chk_username" required>
                <input type="email" name="email" placeholder="Email" id="chk_email" required>
                <span id="email_error" class="error-message"></span>
                <input type="password" name="password" placeholder="Password" required>
                <button id="submit_btn" type="submit">Sign up</button>
            </form>
        </div>

        <div class="login">
            <form id='login'>
                <label for="chk" aria-hidden="true">Login</label>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
            </form>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.min.js"
        integrity="sha512-ykZ1QQr0Jy/4ZkvKuqWn4iF3lqPZyij9iRv6sGqLRdTPkY69YX6+7wvVGmsdBbiIfN/8OdsI7HABjvEok6ZopQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/toastr@2.1.4/toastr.min.js"></script>
    <script src="includes/js/main.js"></script>
    <!-- <script>
        document.getElementById('emailForm').addEventListener('submit', function(event) {
            var emailField = document.getElementById('email');
            var errorSpan = document.getElementById('error');
            var email = emailField.value;
            var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (!emailRegex.test(email)) {
                errorSpan.style.display = 'inline';
                event.preventDefault(); // Prevent form submission
            } else {
                errorSpan.style.display = 'none';
            } -->
        <!-- }); -->
    </script>
</body>

</html>

