document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("#signup");

    form.addEventListener("submit", function(event) {
        event.preventDefault();

        const formData = new FormData(form);

        const data = {
            name: formData.get("name"),
            email: formData.get("email"),
            phone: formData.get("password"),
        };

        
        fetch('crud/backend/create.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(result => {
            alert("Signup  submitted successfully.");
            window.location.href = 'admin.php';
        })
        .catch(error => {
            console.error('Error:', error);
            alert("An error occurred while submitting the application.");
        });
    });
});
