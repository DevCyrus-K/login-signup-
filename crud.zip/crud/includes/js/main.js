$(document).ready(function () {

    // Function to check if username exists
    $('#chk_username').on('keyup', function (e) {
        e.preventDefault();
        let username = $('#chk_username').val();
        $.ajax({
            url: 'backend/check.php',
            type: 'POST',
            data: { username: username, action: "check_username" },
            success: function (response) {
                if (response.trim() === 'exists') {
                    toastr.error("Username already exists! Use another");
                    $('#submit_btn').prop("disabled", true);
                } else {
                    $('#submit_btn').prop("disabled", false);
                }
            }
        });
    });

    // Function to check email format and availability
    $('#chk_email').on('keyup', function (e) {
        e.preventDefault();
        let email = $('#chk_email').val();
        let errorSpan = $('#email_error');
        let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailRegex.test(email)) {
            errorSpan.text('Invalid email format');
            errorSpan.css('display', 'inline');
            $('#submit_btn').prop("disabled", true);
            return;
        } else {
            errorSpan.css('display', 'none');
        }

        $.ajax({
            url: 'backend/check.php',
            type: 'POST',
            data: { email: email, action: "check_email" },
            success: function (response) {
                if (response.trim() === 'exists') {
                    toastr.error("Email already exists! Use another");
                    $('#submit_btn').prop("disabled", true);
                } else {
                    $('#submit_btn').prop("disabled", false);
                }
            }
        });
    });

    // Handle signup form submission
    $('#signup').on('submit', function (e) {
        e.preventDefault();
        const formData = $(this).serialize();
        $.ajax({
            url: 'backend/create.php',
            type: 'POST',
            data: formData,
            success: function (response) {
                console.log(response);
                if (response.trim() === "success") {
                    toastr.success('Sign up submitted successfully');
                    window.location.href = 'sacco/loanform.php'; // Redirect to users page
                } else {
                    toastr.error('An error occurred. Contact Admin!');
                }
            },
            error: function () {
                toastr.error('Error submitting the form. Contact Admin!');
            }
        });
    });

    // Handle login form submission
    $('#login').on('submit', function (e) {
        e.preventDefault();
        const formData = $(this).serialize();
        $.ajax({
            url: 'backend/login.php', // Adjust the URL according to your login handling script
            type: 'POST',
            data: formData,
            success: function (response) {
                console.log(response);
                if (response.trim() === "success") {
                    toastr.success('Login successful');
                    window.location.href = 'sacco/loanform.php'; // Redirect to loan form after login
                } else {
                    toastr.error('Login failed. Please check your credentials.');
                }
            },
            error: function () {
                toastr.error('Error during login. Contact Admin!');
            }
        });
    });

});